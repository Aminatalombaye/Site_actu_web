<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Affichage d'un article</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<?php include_once 'entete.php'; ?>
		<div id="contenu" style="padding-top: 50px;">
    <?php if (!empty($article)): ?>
        <h1><?php echo $article['titre']; ?></h1>
        <span>Publié le <?php echo $article['dateCreation']; ?></span>
        <p><?php echo $article['contenu']; ?></p>
    <?php else: ?>
        <div class="message">L'article n'existe pas</div>
    <?php endif; ?>
</div>

</body>
</html>

