<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Actualités</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<?php
	require_once 'entete.php';

	function afficherArticles($articles) {
		foreach ($articles as $article) {
			echo '<div class="article">';
			echo '<h1><a href="index.php?action=article&id=' . $article['id'] . '">' . $article['titre'] . '</a></h1>';
			echo '<p>' . substr($article['contenu'], 0, 600) . '...</p>';
			echo '</div>';
		}
	}
	?>

	<div id="contenu">
		<?php if (!empty($articles)): ?>
			<?php afficherArticles($articles); ?>
		<?php else: ?>
			<div class="message">Pas d'article</div>
		<?php endif ?>
	</div>

</body>
</html>
