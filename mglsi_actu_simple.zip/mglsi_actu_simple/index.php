<?php
require_once 'Connexion.php';

function getList($table)
{
    $bdd = (new Connexion)->getInstance();
    $query = $bdd->prepare("SELECT * FROM $table");
    $query->execute();
    return $query->fetchAll(PDO::FETCH_ASSOC);
}

function getById($table, $id)
{
    $bdd = (new Connexion)->getInstance();
    $query = $bdd->prepare("SELECT * FROM $table WHERE id = :id");
    $query->bindParam(':id', $id);
    $query->execute();
    return $query->fetch(PDO::FETCH_ASSOC);
}

function getByCategoryId($categoryId)
{
    $bdd = (new Connexion)->getInstance();
    $query = $bdd->prepare('SELECT * FROM Article WHERE categorie = :categoryId');
    $query->bindParam(':categoryId', $categoryId);
    $query->execute();
    return $query->fetchAll(PDO::FETCH_ASSOC);
}

$action = isset($_GET['action']) ? strtolower($_GET['action']) : '';

switch ($action) {
    case 'article':
        $article = isset($_GET['id']) ? getById('Article', $_GET['id']) : null;
        $categories = getList('Categorie');
        require_once 'article.php';
        break;

    case 'categorie':
        $articles = isset($_GET['id']) ? getByCategoryId($_GET['id']) : null;
        $categories = getList('Categorie');
        require_once 'articleCategorie.php';
        break;

    default:
        $articles = getList('Article');
        $categories = getList('Categorie');
        require_once 'accueil.php';
        break;
}
?>
