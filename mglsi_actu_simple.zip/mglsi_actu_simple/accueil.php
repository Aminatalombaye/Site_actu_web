<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Actualités</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<?php include_once 'entete.php'; ?>
	<div id="contenu" style="padding-top: 50px;">
    <?php if (count($articles) > 0): ?>
        <?php foreach ($articles as $article): ?>
            <div class="article">
                <h1><a href="index.php?action=article&id=<?= $article['id'] ?>"><?php echo $article['titre']; ?></a></h1>
                <p><?php echo substr($article['contenu'], 0, 600) . '...'; ?></p>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div class="message">Pas d'article</div>
    <?php endif; ?>
</div>

</body>
</html>

