<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Inscription réussie</title>
</head>
<body align="center">
    <h2>Inscription réussie</h2>
    <p> Votre inscription a été enregistrée avec succès.</p>
    <p>Vous pouvez maintenant vous connecter en utilisant votre nom d'utilisateur et votre mot de passe.</p>
<p>    
            <a href="http://localhost/mglsi_actu/index.php?action=login">Se connecter</a>

</p>
</body>
</html>
        
    